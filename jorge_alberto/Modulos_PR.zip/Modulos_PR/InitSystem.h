#ifndef INITSYSTEM_H_
#define INITSYSTEM_H_


void Init_CS (void) ;
void Software_Trim (void) ;

void Stop_Watchdog (void) ;

#endif /* INITSYSTEM_H_ */
